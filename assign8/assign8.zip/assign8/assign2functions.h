#ifndef ASSIGN2FUNCTIONS_H
#define ASSIGN2FUNCTIONS_H
#include <fstream>
#include <rarray>
#include <mpi.h>
//include </Users/hudsonps/Dropbox/scinet/assign7/rarray/rarray>

void update_ghost_cells(rarray<double, 1> rho, int npnts_percore, int rank, int size);
int number_elements_percore(int ngrid, int rank, int size);
int ind(int ngrid, int rank, int size, int k);
int cumulative_elements_percore(int ngrid, int rank, int size);
void read_data(std::ifstream &infile, double &c, double &tau, double &x1, double &x2, double &runtime, double &dx, double &outtime, std::string &outfilename);
void derived_parameters(int& ngrid, int& npnts, double& dt, int& nsteps, int& nper, double c, double x1, double x2, double runtime, double dx, double outtime);
void report_values(std::ofstream& fout, double c, double tau, double x1, double x2, double runtime, double dx, double outtime, int ngrid, double dt, int nsteps, int nper);
void initialize(rarray<double, 1> x, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double x1, double x2, int ngrid, int npnts_percore, int rank, int size);
void excite(rarray<double, 1> x, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double x1, double x2, int npnts);
void write_snapshots(std::ofstream& fout, int s, int nper, int npnts_percore, rarray <double, 1> x, rarray<double , 1> rho, double dt);
void evolve(double dx, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double c, double tau, double dt, int npnts_percore);
void rotate_rho(rarray <double, 1> rho_prev, rarray <double, 1> rho, rarray <double, 1> rho_next, int npnts_percore);
void shapevstime(std::ofstream& fout, rarray<double, 1> x, double dx, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double c, double tau, double dt,  int npnts_percore, int nsteps, int nper, int rank, int size);

#endif
