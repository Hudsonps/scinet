//assign2functions
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <cmath>
#include <iostream>
#include <rarray>
#include <mpi.h>
//include </Users/hudsonps/Dropbox/scinet/assign7/rarray/rarray>
//#include <omp.h>

int number_elements_percore(int ngrid, int rank, int size)
{
  int remainder = ngrid%size;
  int p;
  p = floor(ngrid/size);

  if(rank < remainder)
    p = p+1; //if npnts/size is not an integer, we must distribute the remaining elements to the cores
  
  //std::cout << p << " rank " << rank << " " << npnts << std::endl;

  //This is the number of elements without taking ghost shells into account
  
  //if(rank == 0)
  // p = p+1;
  //if(rank == size-1)
  // p = p+1; //These if's introduce the sites that account for the boundary conditions
  return p;
}

int cumulative_elements_percore(int ngrid, int rank, int size)
{
  //gives the number of elements being treated by cores 1, 2, ..., rank - 1  (doesn't include rank itself)
  int sum = 0;
  for(int i = 0; i < rank; i++){
    sum = sum + number_elements_percore(ngrid, i, size);
  }
  return sum;
}

int ind(int ngrid, int rank, int size, int k)
{
  //function that maps the indices of each core to an universal index, like the one used in serial programming.
  int p;
  p = cumulative_elements_percore(ngrid, rank, size); //this should correspond to the first element of each core

  if(k > number_elements_percore(ngrid, rank, size))
    {  //k can't be that large, because thats the domain of the next core
     std::cout << "There is something incorrect with the usage of the function ind." << std::endl;
     std::cout << rank << " " << k << " " << p << std::endl;
    }
  return p + k;
}
			     
			    
void read_data(std::ifstream& infile, double &c, double &tau, double &x1, double &x2, double &runtime, double &dx, double &outtime, std::string &outfilename){
  //Physical parameters 
  infile >> c;  //wave speed 
  infile >> tau; //damping time
  infile >> x1; //left most x value
  infile >> x2; //right most x value

  //Simulation parameters
  infile >> runtime; //how long should the simulation try to compute
  infile >> dx; //spatial grid size

  //Output parameters
  infile >> outtime; //how often snapshots of the wave are written out
  infile >> outfilename; //name of file with output data
  
  infile.close(); //close the file where the parameters are stored
}


void derived_parameters(int& ngrid, int& npnts, double& dt, int& nsteps, int& nper, double c, double x1, double x2, double runtime, double dx, double outtime){
  //This funcion defines a set of additional parameters 
    ngrid   = (x2-x1)/dx;  // number of x points
    npnts   = ngrid + 2;   // number of x points including boundary points
    dt      = 0.5*dx/c;    // time step size
    nsteps  = runtime/dt;  // number of steps of that size to reach runtime
    nper    = outtime/dt;  // how many step s between snapshots
}

void report_values(std::ofstream& fout, double c, double tau, double x1, double x2, double runtime, double dx, double outtime, int ngrid, double dt, int nsteps, int nper){
      // Report all the values on the outputfile indicated by fout
    fout << "#c       " << c       << std::endl;
    fout << "#tau     " << tau     << std::endl;
    fout << "#x1      " << x1      << std::endl;
    fout << "#x2      " << x2      << std::endl;
    fout << "#runtime " << runtime << std::endl;
    fout << "#dx      " << dx      << std::endl;
    fout << "#outtime " << outtime << std::endl; 
    fout << "#ngrid   " << ngrid   << std::endl;
    fout << "#dt      " << dt      << std::endl;
    fout << "#nsteps  " << nsteps  << std::endl;    
    fout << "#nper    " << nper    << std::endl;
}

void initialize(rarray<double, 1> x, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double x1, double x2, int ngrid, int npnts, int rank, int size){
    //Initialize simply initializes our vectors.
    //x represents the position axis. This function discretizes the axis by creating a grid determined by x1,x2,ngrid,npnts
    //All the rho's are simply set to 0.
  //The three vectors rho represent the shape of the pulse for three consecutive time steps, which will be necessary to solve a PDE
  int k; 
 for (int i = 1; i <= npnts; i++) {
   k = ind(ngrid, rank, size, i);
   x[i] = x1 + ((k-1)*(x2-x1))/ngrid; 
   rho[i] = 0.0;
   rho_prev[i] = 0.0;
   rho_next[i] = 0.0;
 }
}

void excite(rarray<double, 1> x, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double x1, double x2, int npnts){
    //This function determines the initial shape of rho
    //rho_prev is made equal to rho at this level
    double x14 = 0.25*(x2-x1) + x1;
    double x12 = 0.5*(x2+x1);
    double x34 = 0.75*(x2-x1) + x1;
    for (int i = 1; i <= npnts; i++) {
        if (x[i]<x14 || x[i]>x34)
            rho[i] = 0.0;
        else
            rho[i] = 0.25 - fabs(x[i]-x12)/(x2-x1);
        rho_prev[i] = rho[i];
    }
}


void update_ghost_cells(rarray<double, 1> rho, int npnts_percore, int rank, int size)
{
  //The function excite has filled our vectors for i = 1 to i = nnpnts (per core).
  //Hence, we are still missing i = 0 and i = npnts+1. These are the ghost cells.
  //They must be made to match rho from the adjacent cores.
  int left = rank - 1;
  int right = rank + 1;
  int lefttag = 1;
  int righttag = 1;

  if(rank == 0)
    left = MPI_PROC_NULL; //first core has no left neighbour
  if(rank == size-1)
    right = MPI_PROC_NULL; //right core has no right neighbour

  int ierr;

  if((rank%2) ==0)
    {
      //lets send to the left first
      //then we send to the right
      ierr = MPI_Ssend(&rho[1], 1, MPI_DOUBLE, left, lefttag, MPI_COMM_WORLD);
      ierr = MPI_Ssend(&rho[npnts_percore], 1, MPI_DOUBLE, right, righttag, MPI_COMM_WORLD);
      //now receive 
      ierr = MPI_Recv(&rho[npnts_percore+1], 1, MPI_DOUBLE, right, lefttag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
      ierr = MPI_Recv(&rho[0], 1, MPI_DOUBLE, left, righttag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    }
  else{
    //the odds one should receive from the right first, then from the left
    ierr = MPI_Recv(&rho[npnts_percore+1], 1, MPI_DOUBLE, right, lefttag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
    ierr = MPI_Recv(&rho[0], 1, MPI_DOUBLE, left, righttag, MPI_COMM_WORLD, MPI_STATUS_IGNORE);   
    //now the odd cores send.
    ierr = MPI_Ssend(&rho[1], 1, MPI_DOUBLE, left, lefttag, MPI_COMM_WORLD);
    ierr = MPI_Ssend(&rho[npnts_percore], 1, MPI_DOUBLE, right, righttag, MPI_COMM_WORLD);
 }

  //setting the boundary conditions.                                                                                                                                                
  /* if(rank == 0)
    {
      rho[0] = 0;
    }
  if(rank == size-1)
    {
      rho[npnts_percore+1] = 0;
      } */  
}
 

void write_snapshots(std::ofstream& fout, int s, int nper, int npnts_percore, rarray <double, 1> x, rarray<double , 1> rho, double dt)
{
  //nper = after how many steps a snapshot should be printed
  //s = tracks the current iteration number
  if ((s+1)%nper == 0) {
            fout << "\n\n# t = " << s*dt << "\n";
            for (int i = 1; i <= npnts_percore; i++) 
                fout << x[i] << " " << rho[i] << "\n";
  }
}

void evolve(double dx, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double c, double tau, double dt, int npnts_percore){
      // Evolve
    for (int i = 1; i <= npnts_percore; i++) {
      double laplacian = pow(c/dx,2)*(rho[i+1] + rho[i-1] - 2*rho[i]);
      double friction = (rho[i] - rho_prev[i])/tau;
      rho_next[i] = 2*rho[i] - rho_prev[i] + dt*(laplacian*dt-friction);
    }
}
  
void rotate_rho(rarray <double, 1> rho_prev, rarray <double, 1> rho, rarray <double, 1> rho_next, int npnts_percore){
      for (int i = 1; i <= npnts_percore; i++) {
      double temp = rho_prev[i];
      rho_prev[i] = rho[i];
      rho[i]      = rho_next[i];
      rho_next[i] = temp;
    }
}


void shapevstime(std::ofstream& fout, rarray<double, 1> x, double dx, rarray<double, 1> rho_prev, rarray<double, 1> rho, rarray<double, 1> rho_next, double c, double tau, double dt, int npnts_percore, int nsteps, int nper, int rank, int size){
  
  //Output initial signal
  fout << "\n#t = " << 0 << "\n";
  for (int i = 1; i <= npnts_percore; i++) 
    fout << x[i] << " " << rho[i] << "\n";

  for (int s = 0; s < nsteps; s++) {
    // Set zero dirichlet boundary conditions
    if(rank == 0)
      rho[0] = 0.0;
    if(rank == size-1)
      rho[npnts_percore + 1] = 0.0;

    update_ghost_cells(rho, npnts_percore, rank, size);   //Update the ghost cells necessary for our calculations 

    evolve(dx, rho_prev, rho, rho_next, c, tau, dt, npnts_percore);

    rotate_rho(rho_prev, rho, rho_next, npnts_percore);

    write_snapshots(fout, s, nper, npnts_percore, x, rho, dt);
  }
}


		   

			
