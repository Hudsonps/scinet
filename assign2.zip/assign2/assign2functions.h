#ifndef ASSIGN2FUNCTIONS_H
#define ASSIGN2FUNCTIONS_H
#include <fstream>

void read_data(std::ifstream &infile, double &c, double &tau, double &x1, double &x2, double &runtime, double &dx, double &outtime, std::string &outfilename);
void derived_parameters(int& ngrid, int& npnts, double& dt, int& nsteps, int& nper, double c, double x1, double x2, double runtime, double dx, double outtime);
void report_values(std::ofstream& fout, double c, double tau, double x1, double x2, double runtime, double dx, double outtime, int ngrid, double dt, int nsteps, int nper);
void initialize(double x[], double rho_prev[], double rho[], double rho_next[], double x1, double x2, int ngrid, int npnts);
void excite(double x[], double rho_prev[], double rho[], double rho_next[], double x1, double x2, int npnts);
void shapevstime(std::ofstream& fout, double x[], double dx, double rho_prev[], double rho[], double rho_next[], double c, double x1, double x2, double tau, double dt, int ngrid, int nsteps, int nper);

#endif
