#include <iostream>
#include <fstream>
#include <cmath>
#include "sinandcos.h"
#include <vector>
using namespace std;

int main(){
  //The goal of this function is to have a list of (t, f, g). f and g are define above
  //t should range between -5 and 5.

  ofstream outputfile;
  outputfile.open("lissajous.txt"); //prepares the file for the output (t, f, g)
  
  int N = 2000; //Let's say we want N points between -5 and 5
  //For this assignment we want dt = 0.005. So we use N = 2000
  
  double T_f = 5; //starting time
  double T_i = -5; //final time
  double dt = (T_f - T_i)/(1.*N); //N is an int but 1. converts it to double
  
  double *t = new double[N];
  for(int k = 0; k < N; k++)
    {
      t[k] = T_i + k*dt; //updates time by dt
      outputfile << t[k] << "\t" << f(t[k]) << "\t" << g(t[k]) << endl; //writes (t, f, g)
    } //with this approach, T_f will be missing. We'd rather lose this point to keep clarity.

  outputfile.close();
  delete [] t;
}
