#include <cmath>

double f(double t) {
  return sin(2.*t)/(1. + t*t);
}

double g(double t) {
  return cos(3.*t)/(1. + t*t);
}
