#ifndef SINANDCOS_H
#define SINANDCOS_H

double f(double t);
double g(double t); 

#endif
