sinandcos.o: sinandcos.cc
g++ sinandcos.cc -c -o sinandcos.o
assign1: assign1.cc sinandcos.h sinandcos.cc
g++ assign1.cc -c -o assign1
 

