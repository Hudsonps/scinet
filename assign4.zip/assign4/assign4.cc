//Simulates a one-dimensional damped wave equation
#include <iostream>
#include <fstream>
#include <cmath>
#include <iostream>
#include "assign4functions.h"

int main()
{
  const int dim = 10;
  
  double Aoriginal[dim][dim] = {{1, 11, 7, 9, 7, 11, 7, 9, 2, 11} , {11, 4, 10, 10, 6, 2, 9, 6, 10, 0} , {7, 10, 3, 5, 4, 4, 4, 4, 6, 10,}, {9, 10, 5, 3, 8, 8, 3, 5, 1, 8,}, {7, 6, 4, 8, 8, 10, 5, 6, 10, 0}, {11, 2, 4, 8, 10, 9, 4, 3, 5, 11}, {7, 9, 4, 3, 5, 4, 3, 10, 7, 2}, {9, 6, 4, 5, 6, 3, 10, 11, 1, 7}, {2, 10, 6, 1, 10, 5, 7, 1, 10, 5}, {11, 0, 10, 8, 0, 11, 2, 7, 5, 1}};

  double** A = new double*[dim]; //will be the dynamical form of Aoriginal, which won't be so useful to us
  for(int i = 0; i < dim; i++)
    A[i] = new double[dim];

  for(int i = 0; i < dim; i++){
    for(int j = 0; j < dim; j++){
      A[i][j] = Aoriginal[i][j];
    }
  }

  double *A_array = new double[dim*dim];
  array_sym_matrix(dim, A, A_array);
  //fills A_array with the lower half of the elements of A

  double** eigenvecs = new double*[dim];
  for(int i = 0; i < dim; i++)
    eigenvecs[i] = new double[dim];
  double *eigenvals = new double[dim];
  //The objects above will be used to store the eigenvectors and eigenvalues


  diag_sort(A_array, dim, eigenvecs, eigenvals);  //This function uses lapacke to fill eigenvecs and eigenvals with the eigenvalues
  std::cout << "eigenvalues" << std::endl;
  
    for(int i = 0; i < dim; i++){
      std::cout << eigenvals[i] << std::endl;
    }

    //From now on, assume that eigenvals hold the eigenvalues of A.


    //Verifying Gershgorin
  double *flag = new double[dim];
  verify_Gershgorin(eigenvals, A, dim, flag);

  std::cout << "Now, about the largest eigenvalue" << std::endl;
  std::cout << "It is " << find_largest_eigenvalue(A, dim) << std::endl;

  double diff = find_largest_eigenvalue(A, dim) - eigenvals[dim-1];

  std::cout << "The difference between it and eigenvals obtained by lapack is " << diff << std::endl;

  for(int i = 0; i < dim; i++)
	delete[] A[i];
  delete[] A;
  delete[] eigenvals;
    
  for(int i = 0; i < dim; i++)
	delete[] eigenvecs[i];
  delete[] eigenvecs;
  
  delete[] flag;
  delete[] A_array;
    
}
  

    
    



   
