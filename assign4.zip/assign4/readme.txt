I had issues to make LAPACK actually work on my Mac. Every time I tried to use make, I got the following error:

assign4 hudsonps$ make
g++ -Wall -std=c++11 assign4.o assign4functions.o -o assign4 -llapack -lblas -llapacke -g
ld: library not found for -llapacke
clang: error: linker command failed with exit code 1 (use -v to see invocation)
make: *** [assign4] Error 1

So I asked for a friend of mine that had lapacke working to verify if my results were correct. It might be that the final version I have does not work properly, as I made some small tweaks. But if it does not, it should be very close to a working point.


