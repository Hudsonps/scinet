#include <iostream>
#include <fstream>
#include <cmath>
#include <iostream>
#include "cblas.h"
#include "lapacke.h"


void array_sym_matrix(int dim, double **A, double *A_array)
{
  //This function stores the lower half of a symmetric matrix A in an array form, which is used by LAPACK for diagonalization
  for(int i = 0; i < dim; i++)
    {
      for(int j = 0; j <= i; j++)
	{
	  A_array[i*dim+j] = A[i][j];
	}
    }  
}

void diag_sort(double *matrix, int dim, double **eigenvecs, double *eigenvals){
  //This function diagonalizes matrix
  int lda = dim;
  double *eigvals = new double[dim];
  char jobz;
  char uplo;
  int info;
  
  jobz = 'V';
  uplo = 'L';
  
  info = LAPACKE_dsyev(LAPACK_ROW_MAJOR, jobz, uplo, dim, matrix, lda, 
      eigvals);
      
  /* Check for convergence */
  if( info > 0 ) {
    std::cout << "The algorithm failed to compute eigenvalues. " << std::endl;
    exit( 1 );
  }

  for (int i = 0; i < dim; i++){
    eigenvals[i] = eigvals[i];
    for(int j = 0; j < dim; j++){
      eigenvecs[i][j] = matrix[i*dim + j];
      }
  }
}

void matrix_times_vector(double **A, double *b, int dim, double *c)
{
  //This function is designed to hide the stuff of CBLAS. We assume that A is a matrix, b is a vector and C is the output, A*b = C.
  double *Aaux = new double[dim*dim];
  for(int i = 0; i < dim; i++){
    for(int j = 0; j < dim; j++){
      Aaux[i*dim + j] = A[i][j];
    }
  }

  double alpha = 1., beta = 0.;

  // double *A = new double[m*k], m = dim, k = dim, n = 1
  // double *b = new double[k*n];
  //double *C = new double[m*n];
  int m = dim;
  int k = dim;
  int n = 1;
  
  cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, m, n, k, alpha, Aaux, k, b, n, beta, c, n);
  delete [] Aaux;
}

double vector_times_vector(double *a, double *b, int dim)
{
    //This function is designed to hide the stuff of CBLAS. We assume that a is a vector, b is a vector and c is the output
  //c should be a number.

  double *c = new double[1]; //this is necessary for cblas to work

  double alpha = 1., beta = 0.;

  // double *a = new double[m*k], m = 1, k = dim, n = 1
  // double *b = new double[k*n];
  //double *c = new double[m*n];
  int m = 1;
  int k = dim;
  int n = 1;
  
  cblas_dgemm(CblasRowMajor, CblasNoTrans, CblasNoTrans, m, n, k, alpha, a, k, b, n, beta, c, n);

  return c[0];
  delete [] c;
}

void multiply_by_scalar(double *a, int dim, double alpha)
{
  cblas_dscal(dim, alpha, a, 1);
  
}


void verify_Gershgorin(double *eigenvals, double **A, int dim, double *flag)
{
  //This function verifies if, given a matrix A and its eigenvalues eigevals,
  //each eigenvalue is contained in at least one Gershgorin disk.
  //if one disk is found, the corresponding element in flag will be changed from 0 to 1
  //There is a one to one correspondence between eigenval and flag
  //The theorem is verified if, by the end, flag has only 1's in its body.

  for(int i = 0; i < dim; i++)
    flag[i] = 0; //initializes flag
  
  
  
  for(int i = 0; i < dim; i++){
    double radius = 0;
    for(int j = 0; j < dim; j++){
	if(j != i)
	  radius = radius + fabs(A[i][j]);
      }
    for(int k = 0; k < dim; k++){
      //now that we know the radius, go through every eigenvalue
      if(fabs(eigenvals[k] - A[i][i]) < radius)
	 flag[k] = 1;
    }	    
  }
  std::cout << "Starting Gershgorin test" << std::endl;
      for(int i = 0; i < dim; i++)
	std::cout << flag[i] << std::endl;
      std::cout << "Test successful if only 1's were printed" << std::endl;
      
}

double find_largest_eigenvalue(double **A, int dim)
{
  double eigenvalue = 1;
  double oldeigenvalue = 0;

  double *v = new double[dim];
  for(int i = 0; i < dim; i++)
    v[i] = 1; //This vector starts with 1 in every direction

  double *vupdated = new double[dim];
  for(int i = 0; i < dim; i++)
    vupdated[i] = 0;

  double numerator;
  double normnew;
  double normsqrd; //will be used later to store the norm squared of 

  while(fabs(eigenvalue - oldeigenvalue) > 1e-5)
    {
      oldeigenvalue = eigenvalue;
      
      matrix_times_vector(A, v, dim, vupdated);
      //vupdated = A * v      
  //If v were the eigenvector we seek, then A * v = lambda v
  //vupdated would be lambda * v.
  //Hence, vupdate * v / (v*v) = lambda.
  //calculate this object next
      normsqrd = vector_times_vector(v, v, dim); //This is v*v
      numerator = vector_times_vector(v, vupdated, dim); //This is v *vupdated = v * A * v.
      eigenvalue = numerator/normsqrd; //If this number is correct, it should not change compared to the previous iteration.
  //When the while loop restarts, we will know if eigenvalue is close enough from the one of the previous iteration

      //In this approach vupdated will grow arbitrarily, so it is better to normalize it.
      normnew = vector_times_vector(vupdated, vupdated, dim);
      cblas_dscal(dim,1/normnew,vupdated,1);
      //With this, vupdated has been normalized
      //Finally, we need v to become vupdated.
      for(int i = 0; i < dim; i++)
	  v[i] = vupdated[i];
      //Now v contains the vupdated.
    }
  delete [] v;
  delete [] vupdated;
  //if we left this loop, then the result must be the eigenvalue
  return eigenvalue;
     
  
}
  
  


  
  
  
