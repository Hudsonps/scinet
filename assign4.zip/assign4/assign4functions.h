#ifndef ASSIGN2FUNCTIONS_H
#define ASSIGN2FUNCTIONS_H

int index(int i, int j);
void array_sym_matrix(int dim, double **A, double *A_array);
void diag_sort(double *matrix, int dim, double **eigenvecs, double *eigenvals);
void matrix_times_vector(double **A, double *b, int dim, double *C);
void verify_Gershgorin(double *eigenvals, double **A, int dim, double *flag);
double find_largest_eigenvalue(double **A, int dim);
double vector_times_vector(double *a, double *b, int dim);
void multiply_by_scalar(double *a, int dim, double alpha);


#endif
